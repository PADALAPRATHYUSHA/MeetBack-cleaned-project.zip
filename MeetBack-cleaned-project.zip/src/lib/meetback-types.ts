export interface Participant {
  id: string
  name: string
  color: string
  joinedAt: number
  muted: boolean
  camOff: boolean
  isBot: boolean
}

export interface ChatMessage {
  id: string
  participantId: string
  name: string
  content: string
  timestamp: number
  kind: 'user' | 'system'
}

export interface RoomState {
  code: string
  createdAt: number
  participants: Participant[]
  messages: ChatMessage[]
}

export interface ConnectionStats {
  latencyMs: number
  jitterMs: number
  quality: 'excellent' | 'good' | 'fair'
}

export interface MeetingEventData {
  event: string
  at: number
  label: string
}

export interface MeetingRecord {
  code: string
  startedAt: number
  endedAt: number
  participants: { name: string; color: string; isBot: boolean }[]
  messages: { name: string; content: string; kind: string }[]
  events: MeetingEventData[]
  stats: ConnectionStats | null
}

export interface HindsightInsight {
  headline: string
  summary: string
  highlights: string[]
  actionItems: string[]
  suggestions: string[]
  sentimentScore: number // 0-100
  sentimentLabel: string
}

export type CallPhase =
  | 'landing'
  | 'lobby'
  | 'connecting'
  | 'in-call'
  | 'success'
  | 'hindsight'
