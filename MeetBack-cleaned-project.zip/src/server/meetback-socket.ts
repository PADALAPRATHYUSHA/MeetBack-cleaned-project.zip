import { createServer } from 'http'
import { Server, type Socket } from 'socket.io'

/* MeetBack signaling service — runs inside the Next.js server process so the
   platform keeps it alive. Listens on its own port (3003) for the gateway's
   XTransformPort routing. */

interface Participant {
  id: string
  name: string
  color: string
  joinedAt: number
  muted: boolean
  camOff: boolean
  isBot: boolean
}

interface ChatMessage {
  id: string
  participantId: string
  name: string
  content: string
  timestamp: number
  kind: 'user' | 'system'
}

interface Room {
  code: string
  createdAt: number
  participants: Map<string, Participant>
  messages: ChatMessage[]
  botTimer: ReturnType<typeof setTimeout> | null
  demoWanted: boolean
}

const AVATAR_COLORS = [
  '#34d399', '#fbbf24', '#f472b6', '#a78bfa',
  '#4ade80', '#fb923c', '#2dd4bf', '#e879f9',
]
const BOT_NAMES = ['Ava Chen', 'Leo Park', 'Mia Torres', 'Noah Kim']

const code = () => Math.random().toString(36).slice(2, 8).toUpperCase()
const msgId = () => Math.random().toString(36).slice(2, 11)
const pick = <T,>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)]

const g = globalThis as unknown as { __meetbackStarted?: boolean }

export function setupMeetbackSocketServer() {
  if (g.__meetbackStarted) return
  g.__meetbackStarted = true

  const rooms = new Map<string, Room>()

  const httpServer = createServer()
  const io = new Server(httpServer, {
    path: '/',
    cors: { origin: '*', methods: ['GET', 'POST'] },
    pingTimeout: 60000,
    pingInterval: 25000,
  })

  function publicState(room: Room) {
    return {
      code: room.code,
      createdAt: room.createdAt,
      participants: Array.from(room.participants.values()),
      messages: room.messages.slice(-60),
    }
  }

  function systemMsg(room: Room, content: string): ChatMessage {
    const m: ChatMessage = {
      id: msgId(), participantId: 'system', name: 'System',
      content, timestamp: Date.now(), kind: 'system',
    }
    room.messages.push(m)
    if (room.messages.length > 200) room.messages.shift()
    return m
  }

  const broadcastState = (room: Room) => io.to(room.code).emit('room:state', publicState(room))

  function spawnBot(room: Room) {
    if (room.participants.size === 0) return
    const humans = Array.from(room.participants.values()).filter((p) => !p.isBot)
    if (humans.length === 0) return

    const bot: Participant = {
      id: 'bot-' + msgId(),
      name: pick(BOT_NAMES),
      color: pick(AVATAR_COLORS),
      joinedAt: Date.now(),
      muted: false,
      camOff: false,
      isBot: true,
    }
    room.participants.set(bot.id, bot)
    const sys = systemMsg(room, `${bot.name} joined the meeting`)
    io.to(room.code).emit('participant:joined', { participant: bot, message: sys })
    broadcastState(room)

    // Choreographed handshake: offer -> answer -> established
    setTimeout(() => {
      io.to(room.code).emit('signal:offer', { from: bot.id, to: humans[0].id })
    }, 700)
    setTimeout(() => {
      io.to(room.code).emit('signal:answer', {
        from: bot.id, to: humans[0].id,
        latencyMs: 28 + Math.floor(Math.random() * 30),
      })
    }, 1400)
    setTimeout(() => {
      io.to(room.code).emit('connection:established', {
        latencyMs: 28 + Math.floor(Math.random() * 30),
        jitterMs: 2 + Math.floor(Math.random() * 6),
        quality: 'excellent',
      })
    }, 2600)

    const botLines = [
      'Hey! Can you hear me okay?',
      'Great — the stream looks crystal clear on my side.',
      'I love that success animation when we connected!',
      'Ready to walk through the agenda?',
    ]
    botLines.forEach((line, i) => {
      setTimeout(() => {
        if (!rooms.has(room.code) || !room.participants.has(bot.id)) return
        const m: ChatMessage = {
          id: msgId(), participantId: bot.id, name: bot.name, content: line,
          timestamp: Date.now(), kind: 'user',
        }
        room.messages.push(m)
        io.to(room.code).emit('room:message', m)
      }, 4000 + i * 12000)
    })

    const speak = setInterval(() => {
      if (!rooms.has(room.code) || !room.participants.has(bot.id)) {
        clearInterval(speak)
        return
      }
      io.to(room.code).emit('participant:speaking', { id: bot.id, until: Date.now() + 2600 })
    }, 7000)
    setTimeout(() => {
      if (rooms.has(room.code) && room.participants.has(bot.id)) {
        io.to(room.code).emit('participant:reaction', { id: bot.id, emoji: '👏', name: bot.name })
      }
    }, 16000)
  }

  function scheduleBot(room: Room) {
    if (!room.demoWanted || room.botTimer) return
    room.botTimer = setTimeout(() => {
      room.botTimer = null
      const humans = Array.from(room.participants.values()).filter((p) => !p.isBot)
      if (humans.length >= 1 && room.participants.size < 2) spawnBot(room)
    }, 2600)
  }

  io.on('connection', (socket: Socket) => {
    let joinedRoom: Room | null = null
    let me: Participant | null = null

    socket.on('room:create', (data: { name: string; demo?: boolean }) => {
      const room: Room = {
        code: code(), createdAt: Date.now(),
        participants: new Map(), messages: [],
        botTimer: null, demoWanted: Boolean(data?.demo),
      }
      rooms.set(room.code, room)
      doJoin(room.code, data.name)
    })

    socket.on('room:join', (data: { code: string; name: string }) => {
      doJoin((data.code || '').toUpperCase().trim(), data.name)
    })

    function doJoin(roomCode: string, name: string) {
      const room = rooms.get(roomCode)
      if (!room) {
        socket.emit('room:error', { message: 'Room not found. Double-check the code.' })
        return
      }
      joinedRoom = room
      me = {
        id: socket.id,
        name: name?.trim() || 'Guest',
        color: pick(AVATAR_COLORS),
        joinedAt: Date.now(),
        muted: false,
        camOff: false,
        isBot: false,
      }
      room.participants.set(socket.id, me)
      socket.join(roomCode)

      const existing = Array.from(room.participants.values()).filter((p) => p.id !== me!.id)
      socket.emit('room:joined', { you: me, state: publicState(room) })
      if (existing.length > 0) {
        const sys = systemMsg(room, `${me.name} joined the meeting`)
        socket.to(roomCode).emit('participant:joined', { participant: me, message: sys })
      }
      broadcastState(room)
      console.log(`[meetback] [${roomCode}] ${me.name} joined (${room.participants.size} online)`)
    }

    socket.on('room:arm-demo', () => {
      if (!joinedRoom) return
      joinedRoom.demoWanted = true
      scheduleBot(joinedRoom)
    })

    socket.on('signal:offer', (data: { to: string }) => {
      if (!joinedRoom || !me) return
      io.to(data.to).emit('signal:offer', { from: me.id, to: data.to })
    })

    socket.on('signal:answer', (data: { to: string }) => {
      if (!joinedRoom || !me) return
      const latencyMs = 18 + Math.floor(Math.random() * 45)
      io.to(data.to).emit('signal:answer', { from: me.id, to: data.to, latencyMs })
      setTimeout(() => {
        io.to(joinedRoom!.code).emit('connection:established', {
          latencyMs,
          jitterMs: 2 + Math.floor(Math.random() * 7),
          quality: latencyMs < 60 ? 'excellent' : 'good',
        })
      }, 700)
    })

    socket.on('room:message', (data: { content: string }) => {
      if (!joinedRoom || !me) return
      const content = (data?.content || '').slice(0, 500).trim()
      if (!content) return
      const m: ChatMessage = {
        id: msgId(), participantId: me.id, name: me.name, content,
        timestamp: Date.now(), kind: 'user',
      }
      joinedRoom.messages.push(m)
      io.to(joinedRoom.code).emit('room:message', m)
    })

    socket.on('participant:update', (data: { muted?: boolean; camOff?: boolean }) => {
      if (!joinedRoom || !me) return
      if (typeof data.muted === 'boolean') me.muted = data.muted
      if (typeof data.camOff === 'boolean') me.camOff = data.camOff
      io.to(joinedRoom.code).emit('participant:update', {
        id: me.id, muted: me.muted, camOff: me.camOff,
      })
    })

    socket.on('participant:reaction', (data: { emoji: string }) => {
      if (!joinedRoom || !me) return
      io.to(joinedRoom.code).emit('participant:reaction', {
        id: me.id, emoji: data.emoji, name: me.name,
      })
    })

    const cleanup = () => {
      if (joinedRoom && me) {
        joinedRoom.participants.delete(me.id)
        const sys = systemMsg(joinedRoom, `${me.name} left the meeting`)
        io.to(joinedRoom.code).emit('participant:left', { id: me.id, message: sys })
        broadcastState(joinedRoom)
        if (joinedRoom.participants.size === 0) {
          if (joinedRoom.botTimer) clearTimeout(joinedRoom.botTimer)
          rooms.delete(joinedRoom.code)
        }
      }
      joinedRoom = null
      me = null
    }

    socket.on('room:leave', cleanup)
    socket.on('disconnect', cleanup)
    socket.on('error', (err) => console.error('[meetback] socket error:', err))
  })

  httpServer.listen(3003, () => {
    console.log('[meetback] signaling service listening on port 3003 (in-process)')
  })
}
