'use client'

import { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Check, Loader2, Radar, KeyRound, Handshake, Video, ShieldCheck } from 'lucide-react'

export interface ConnectStep {
  id: string
  label: string
  detail: string
  icon: React.ReactNode
  state: 'pending' | 'active' | 'done'
}

interface ConnectingOverlayProps {
  userName: string
  roomCode: string
  steps: ConnectStep[]
}

export function ConnectingOverlay({ userName, roomCode, steps }: ConnectingOverlayProps) {
  const [dots, setDots] = useState('')

  useEffect(() => {
    const id = setInterval(() => {
      setDots((d) => (d.length >= 3 ? '' : d + '.'))
    }, 400)
    return () => clearInterval(id)
  }, [])

  return (
    <motion.div
      className="fixed inset-0 z-[80] flex items-center justify-center bg-neutral-950/95 backdrop-blur-xl"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      role="status"
      aria-live="polite"
    >
      {/* ambient scan glow */}
      <motion.div
        className="absolute h-96 w-96 rounded-full bg-emerald-500/10 blur-[100px]"
        animate={{ scale: [1, 1.25, 1], opacity: [0.5, 0.9, 0.5] }}
        transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
      />

      <div className="relative w-full max-w-md px-6">
        <div className="mb-8 text-center">
          <motion.div
            className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl border border-white/10 bg-white/5"
            animate={{ rotate: [0, 0, 360] }}
            transition={{ duration: 2.4, repeat: Infinity, ease: 'easeInOut' }}
          >
            <Radar className="h-7 w-7 text-emerald-400" aria-hidden />
          </motion.div>
          <h2 className="text-xl font-semibold text-white">
            Establishing your secure link{dots}
          </h2>
          <p className="mt-1.5 text-sm text-white/50">
            Room <span className="font-mono font-semibold text-emerald-300">{roomCode}</span> · as{' '}
            {userName}
          </p>
        </div>

        <ol className="space-y-2.5" aria-label="Connection progress">
          <AnimatePresence>
            {steps.map((step, idx) => (
              <motion.li
                key={step.id}
                initial={{ opacity: 0, x: -18 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.08 }}
                className={`flex items-center gap-3.5 rounded-xl border px-4 py-3 transition-colors duration-300 ${
                  step.state === 'done'
                    ? 'border-emerald-400/25 bg-emerald-400/[0.07]'
                    : step.state === 'active'
                      ? 'border-white/15 bg-white/[0.06]'
                      : 'border-white/5 bg-white/[0.02]'
                }`}
              >
                <span
                  className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-lg ${
                    step.state === 'done'
                      ? 'bg-emerald-400/20 text-emerald-300'
                      : step.state === 'active'
                        ? 'bg-white/10 text-white'
                        : 'bg-white/5 text-white/30'
                  }`}
                >
                  {step.state === 'done' ? (
                    <motion.span initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: 'spring', stiffness: 400, damping: 18 }}>
                      <Check className="h-4.5 w-4.5" aria-hidden />
                    </motion.span>
                  ) : step.state === 'active' ? (
                    <Loader2 className="h-4.5 w-4.5 animate-spin" aria-hidden />
                  ) : (
                    step.icon
                  )}
                </span>
                <span className="min-w-0 flex-1">
                  <span
                    className={`block text-sm font-medium ${
                      step.state === 'pending' ? 'text-white/35' : 'text-white/90'
                    }`}
                  >
                    {step.label}
                  </span>
                  <span className="block truncate text-xs text-white/40">
                    {step.state === 'done' ? step.detail : step.state === 'active' ? 'working…' : 'queued'}
                  </span>
                </span>
                {step.state === 'done' && (
                  <motion.span
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="text-[10px] font-semibold tracking-wider text-emerald-400/80 uppercase"
                  >
                    ok
                  </motion.span>
                )}
              </motion.li>
            ))}
          </AnimatePresence>
        </ol>
      </div>
    </motion.div>
  )
}

export const STEP_ICONS = {
  media: <Video className="h-4.5 w-4.5" aria-hidden />,
  channel: <ShieldCheck className="h-4.5 w-4.5" aria-hidden />,
  ice: <Radar className="h-4.5 w-4.5" aria-hidden />,
  keys: <KeyRound className="h-4.5 w-4.5" aria-hidden />,
  handshake: <Handshake className="h-4.5 w-4.5" aria-hidden />,
}
