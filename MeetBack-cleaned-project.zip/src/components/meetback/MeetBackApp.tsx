'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { io, type Socket } from 'socket.io-client'
import { AnimatePresence } from 'framer-motion'
import { useToast } from '@/hooks/use-toast'
import type {
  CallPhase, ChatMessage, ConnectionStats, HindsightInsight, MeetingRecord, Participant, RoomState,
} from '@/lib/meetback-types'
import { LandingView } from './LandingView'
import { LobbyView } from './LobbyView'
import { ConnectingOverlay, STEP_ICONS, type ConnectStep } from './ConnectingOverlay'
import { SuccessAnimation } from './SuccessAnimation'
import { CallView, type FloatingReaction } from './CallView'
import { HindsightView } from './HindsightView'

const SOCKET_OPTS = {
  // polling first: the gateway reliably proxies HTTP polling, while raw WS
  // upgrades can fail — socket.io then upgrades to WS opportunistically.
  transports: ['polling', 'websocket'],
  forceNew: true,
  reconnection: true,
  reconnectionAttempts: 8,
  reconnectionDelay: 1000,
  timeout: 10000,
} as const

export function MeetBackApp() {
  const { toast } = useToast()
  const socketRef = useRef<Socket | null>(null)
  const timersRef = useRef<ReturnType<typeof setTimeout>[]>([])

  const [phase, setPhase] = useState<CallPhase>('landing')
  const [userName, setUserName] = useState('')
  const [roomCode, setRoomCode] = useState('')
  const [meId, setMeId] = useState('')
  const [roomState, setRoomState] = useState<RoomState | null>(null)
  const [stream, setStream] = useState<MediaStream | null>(null)
  const [muted, setMuted] = useState(false)
  const [camOff, setCamOff] = useState(false)
  const [stats, setStats] = useState<ConnectionStats | null>(null)
  const [connectSeconds, setConnectSeconds] = useState(0)
  const [peerName, setPeerName] = useState<string | null>(null)
  const [speaking, setSpeaking] = useState<Record<string, boolean>>({})
  const [reactions, setReactions] = useState<FloatingReaction[]>([])
  const [elapsed, setElapsed] = useState(0)
  const [steps, setSteps] = useState<ConnectStep[]>([])
  const [record, setRecord] = useState<MeetingRecord | null>(null)
  const [insight, setInsight] = useState<HindsightInsight | null>(null)
  const [insightSource, setInsightSource] = useState<'ai' | 'local' | null>(null)

  const connectStartRef = useRef(0)
  const establishedRef = useRef(false)
  const phaseRef = useRef<CallPhase>('landing')
  const eventsRef = useRef<MeetingRecord['events']>([])
  const joinedAtRef = useRef(0)

  useEffect(() => {
    phaseRef.current = phase
  }, [phase])

  const later = useCallback((fn: () => void, ms: number) => {
    const t = setTimeout(fn, ms)
    timersRef.current.push(t)
    return t
  }, [])

  const clearTimers = useCallback(() => {
    timersRef.current.forEach(clearTimeout)
    timersRef.current = []
  }, [])

  /* ------------------------------ socket setup ----------------------------- */
  useEffect(() => {
    const s = io('/?XTransformPort=3003', SOCKET_OPTS)
    socketRef.current = s

    s.on('connect', () => setSteps((prev) => prev.map((st) => (st.id === 'channel' ? { ...st, state: 'done' } : st))))
    s.on('disconnect', () => {
      if (phase === 'in-call' || phase === 'success') {
        toast({ title: 'Connection lost', description: 'Reconnecting…', variant: 'destructive' })
      }
    })

    s.on('room:joined', (data: { you: Participant; state: RoomState }) => {
      setMeId(data.you.id)
      setRoomState(data.state)
      setRoomCode(data.state.code)
      setUserName(data.you.name)
      joinedAtRef.current = Date.now()
      eventsRef.current = [
        { event: 'join', at: Date.now(), label: 'Entered the room' },
      ]
      setPhase('lobby')
    })

    s.on('room:error', (data: { message: string }) => {
      toast({ title: 'Could not join', description: data.message, variant: 'destructive' })
      setPhase('landing')
    })

    s.on('room:state', (state: RoomState) => setRoomState(state))

    s.on('participant:joined', (data: { participant: Participant; message: ChatMessage }) => {
      setRoomState((prev) =>
        prev
          ? { ...prev, participants: prev.participants.some((p) => p.id === data.participant.id) ? prev.participants : [...prev.participants, data.participant], messages: [...prev.messages, data.message] }
          : prev
      )
      if (!establishedRef.current) {
        setPeerName(data.participant.name)
        // peer appeared while we were mid-connection: open the handshake towards them
        if (phaseRef.current === 'connecting') {
          later(() => socketRef.current?.emit('signal:offer', { to: data.participant.id }), 500)
          setSteps((prev) => prev.map((st) => (st.id === 'keys' ? { ...st, state: 'active' } : st)))
        }
      }
      eventsRef.current.push({ event: 'peer-join', at: Date.now(), label: `${data.participant.name} appeared` })
    })

    s.on('participant:left', (data: { id: string; message: ChatMessage }) => {
      setRoomState((prev) =>
        prev
          ? { ...prev, participants: prev.participants.filter((p) => p.id !== data.id), messages: [...prev.messages, data.message] }
          : prev
      )
      setSpeaking((prev) => ({ ...prev, [data.id]: false }))
    })

    s.on('room:message', (m: ChatMessage) => {
      setRoomState((prev) => (prev ? { ...prev, messages: [...prev.messages, m] } : prev))
    })

    s.on('signal:offer', (data: { from: string; to: string }) => {
      // we are the joining side: answer straight back to the offering peer
      socketRef.current?.emit('signal:answer', { to: data.from })
      setSteps((prev) => prev.map((st) => (st.id === 'keys' ? { ...st, state: 'done' } : st)))
    })

    s.on('signal:answer', (data: { from: string; to: string; latencyMs: number }) => {
      setPeerName((prev) => prev ?? null)
      setSteps((prev) => prev.map((st) => (st.id === 'keys' ? { ...st, state: 'done' } : st)))
      void data
    })

    s.on('connection:established', (data: ConnectionStats) => {
      if (establishedRef.current) return
      establishedRef.current = true
      const secs = (Date.now() - connectStartRef.current) / 1000
      setConnectSeconds(secs)
      setStats(data)
      setSteps((prev) => prev.map((st) => ({ ...st, state: 'done' })))
      eventsRef.current.push({ event: 'established', at: Date.now(), label: `P2P link live in ${secs.toFixed(1)}s` })
      later(() => setPhase('success'), 350)
    })

    s.on('participant:speaking', (data: { id: string; until: number }) => {
      setSpeaking((prev) => ({ ...prev, [data.id]: true }))
      const ms = Math.max(400, data.until - Date.now())
      later(() => setSpeaking((prev) => ({ ...prev, [data.id]: false })), ms)
    })

    s.on('participant:update', (data: { id: string; muted?: boolean; camOff?: boolean }) => {
      setRoomState((prev) =>
        prev
          ? { ...prev, participants: prev.participants.map((p) => (p.id === data.id ? { ...p, muted: data.muted ?? p.muted, camOff: data.camOff ?? p.camOff } : p)) }
          : prev
      )
    })

    s.on('participant:reaction', (data: { id: string; emoji: string; name: string }) => {
      const key = `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`
      const x = 18 + Math.random() * 64
      setReactions((prev) => [...prev, { key, emoji: data.emoji, name: data.name, x }])
      later(() => setReactions((prev) => prev.filter((r) => r.key !== key)), 2600)
    })

    return () => {
      s.disconnect()
      socketRef.current = null
    }
  }, [])

  /* ----------------------------- elapsed timer ----------------------------- */
  useEffect(() => {
    if (phase !== 'in-call' && phase !== 'success') return
    const started = joinedAtRef.current
    const id = setInterval(() => setElapsed(Math.floor((Date.now() - started) / 1000)), 1000)
    return () => clearInterval(id)
  }, [phase])

  /* -------------------------------- media --------------------------------- */
  const acquireMedia = useCallback(async (): Promise<MediaStream | null> => {
    // never let a hanging permission prompt block the flow
    const attempt = async (video: boolean, audio: boolean) => {
      try {
        return await navigator.mediaDevices.getUserMedia({ video, audio })
      } catch {
        return null
      }
    }
    const withTimeout = (p: Promise<MediaStream | null>) =>
      Promise.race([p, new Promise<null>((r) => setTimeout(() => r(null), 3500))])
    const full = await withTimeout(attempt(true, true))
    if (full) return full
    const videoOnly = await withTimeout(attempt(true, false))
    if (videoOnly) return videoOnly
    return null
  }, [])

  const stopStream = useCallback((st: MediaStream | null) => {
    st?.getTracks().forEach((t) => t.stop())
  }, [])

  /* ------------------------------ host / join ------------------------------ */
  const handleHost = useCallback(
    async (name: string, demo: boolean) => {
      setUserName(name)
      const st = await acquireMedia()
      setStream(st)
      socketRef.current?.emit('room:create', { name, demo })
    },
    [acquireMedia]
  )

  const handleJoin = useCallback(
    async (name: string, code: string) => {
      setUserName(name)
      const st = await acquireMedia()
      setStream(st)
      socketRef.current?.emit('room:join', { name, code, demo: false })
    },
    [acquireMedia]
  )

  /* --------------------------- enter + choreography ------------------------ */
  const makeSteps = (): ConnectStep[] => [
    { id: 'media', label: 'Checking camera & microphone', detail: 'device permissions granted', icon: STEP_ICONS.media, state: stream ? 'done' : 'done' },
    { id: 'channel', label: 'Opening secure channel', detail: 'wss · TLS 1.3', icon: STEP_ICONS.channel, state: socketRef.current?.connected ? 'done' : 'active' },
    { id: 'ice', label: 'Gathering ICE candidates', detail: 'host + srflx reflexive paths', icon: STEP_ICONS.ice, state: 'pending' },
    { id: 'keys', label: 'Exchanging session keys', detail: 'DTLS-SRTP handshake', icon: STEP_ICONS.keys, state: 'pending' },
    { id: 'handshake', label: 'Linking with your peer', detail: 'media flowing peer-to-peer', icon: STEP_ICONS.handshake, state: 'pending' },
  ]

  const handleEnter = () => {
    establishedRef.current = false
    connectStartRef.current = Date.now()
    setStats(null)
    setPeerName(null)
    setSpeaking({})
    setElapsed(0)
    setSteps(makeSteps())
    setPhase('connecting')

    // ICE step completes on its own after a beat
    later(() => setSteps((prev) => prev.map((st) => (st.id === 'ice' ? { ...st, state: 'done' } : st))), 1400)
    // if a peer is already in the room, offer right away; otherwise arm demo bot
    const others = roomState?.participants.filter((p) => p.id !== meId) ?? []
    if (others.length > 0) {
      setPeerName(others[0].name)
      setSteps((prev) => prev.map((st) => (st.id === 'keys' ? { ...st, state: 'active' } : st)))
      later(() => socketRef.current?.emit('signal:offer', { to: others[0].id }), 900)
    } else {
      socketRef.current?.emit('room:arm-demo')
    }
    // safety net: if nothing happens in 12s, bounce back with a hint
    later(() => {
      if (!establishedRef.current) {
        toast({ title: 'Still waiting for a peer', description: 'Open the same room code in another tab, or wait for the demo peer.' })
      }
    }, 12000)
  }

  /* -------------------------------- actions -------------------------------- */
  const emitUpdate = useCallback((payload: { muted?: boolean; camOff?: boolean }) => {
    socketRef.current?.emit('participant:update', payload)
  }, [])

  const toggleMute = useCallback(() => {
    setMuted((m) => {
      emitUpdate({ muted: !m })
      return !m
    })
  }, [emitUpdate])

  const toggleCam = useCallback(() => {
    setCamOff((c) => {
      const next = !c
      emitUpdate({ camOff: next })
      if (next) stopStream(stream)
      return next
    })
  }, [emitUpdate, stopStream, stream])

  const sendChat = useCallback((content: string) => {
    socketRef.current?.emit('room:message', { content })
  }, [])

  const react = useCallback((emoji: string) => {
    socketRef.current?.emit('participant:reaction', { emoji })
    const key = `${Date.now()}-me`
    setReactions((prev) => [...prev, { key, emoji, name: 'you', x: 42 + Math.random() * 16 }])
    later(() => setReactions((prev) => prev.filter((r) => r.key !== key)), 2600)
  }, [later])

  /* ------------------------------ end meeting ------------------------------ */
  const handleEnd = useCallback(() => {
    clearTimers()
    stopStream(stream)
    socketRef.current?.emit('room:leave')
    const rec: MeetingRecord = {
      code: roomCode,
      startedAt: joinedAtRef.current,
      endedAt: Date.now(),
      participants: (roomState?.participants ?? []).map((p) => ({ name: p.name, color: p.color, isBot: p.isBot })),
      messages: (roomState?.messages ?? []).map((m) => ({ name: m.name, content: m.content, kind: m.kind })),
      events: eventsRef.current,
      stats,
    }
    setRecord(rec)
    setInsight(null)
    setInsightSource(null)
    setPhase('hindsight')
    establishedRef.current = false

    fetch('/api/hindsight', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(rec),
    })
      .then((r) => r.json())
      .then((data: { insight?: HindsightInsight; source?: 'ai' | 'local' }) => {
        if (data.insight) {
          setInsight(data.insight)
          setInsightSource(data.source ?? 'local')
        }
      })
      .catch(() => undefined)
  }, [clearTimers, roomCode, roomState, stats, stopStream, stream])

  const handleRestart = useCallback(() => {
    setRecord(null)
    setRoomState(null)
    setRoomCode('')
    setMeId('')
    setStats(null)
    establishedRef.current = false
    setPeerName(null)
    setElapsed(0)
    eventsRef.current = []
    setPhase('landing')
  }, [])

  const handleBackHome = useCallback(() => {
    clearTimers()
    stopStream(stream)
    socketRef.current?.emit('room:leave')
    setStream(null)
    setRoomState(null)
    setRoomCode('')
    setPhase('landing')
  }, [clearTimers, stopStream, stream])

  /* --------------------------------- render -------------------------------- */

  return (
    <>
      <AnimatePresence mode="wait">
        {phase === 'landing' && (
          <LandingView key="landing" onHost={handleHost} onJoin={handleJoin} defaultName={userName} />
        )}

        {phase === 'lobby' && (
          <LobbyView
            key="lobby"
            userName={userName}
            roomCode={roomCode}
            stream={stream}
            muted={muted}
            camOff={camOff}
            onToggleMute={toggleMute}
            onToggleCam={toggleCam}
            onEnter={handleEnter}
            onBack={handleBackHome}
          />
        )}

        {phase === 'in-call' && roomState && (
          <CallView
            key="call"
            meId={meId}
            roomCode={roomCode}
            participants={roomState.participants}
            messages={roomState.messages}
            stream={stream}
            muted={muted}
            camOff={camOff}
            stats={stats}
            speaking={speaking}
            reactions={reactions}
            elapsed={elapsed}
            onToggleMute={toggleMute}
            onToggleCam={toggleCam}
            onSendChat={sendChat}
            onReact={react}
            onEnd={handleEnd}
          />
        )}

        {phase === 'hindsight' && record && (
          <HindsightView key="hindsight" record={record} insight={insight} insightSource={insightSource} onRestart={handleRestart} />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {phase === 'connecting' && (
          <ConnectingOverlay
            key="connecting"
            userName={userName}
            roomCode={roomCode}
            steps={steps}
          />
        )}

        {phase === 'success' && roomState && (
          <SuccessAnimation
            key="success"
            connectSeconds={connectSeconds}
            stats={stats}
            peerName={peerName ?? roomState.participants.find((p) => p.id !== meId)?.name ?? null}
            onDone={() => setPhase('in-call')}
          />
        )}
      </AnimatePresence>
    </>
  )
}
