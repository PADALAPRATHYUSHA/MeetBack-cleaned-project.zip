'use client'

import { useEffect } from 'react'
import { motion } from 'framer-motion'
import confetti from 'canvas-confetti'
import { AudioLines, ShieldCheck, Zap } from 'lucide-react'

const PALETTE = ['#34d399', '#2dd4bf', '#fbbf24', '#ffffff', '#a7f3d0', '#5eead4']

function burstConfetti() {
  const defaults = {
    colors: PALETTE,
    disableForReducedMotion: true,
    zIndex: 100,
  }
  confetti({
    ...defaults,
    particleCount: 90,
    spread: 100,
    startVelocity: 42,
    origin: { y: 0.62 },
    scalar: 0.9,
  })
  setTimeout(() => {
    confetti({ ...defaults, particleCount: 45, angle: 60, spread: 60, origin: { x: 0, y: 0.7 } })
    confetti({ ...defaults, particleCount: 45, angle: 120, spread: 60, origin: { x: 1, y: 0.7 } })
  }, 180)
}

interface SuccessAnimationProps {
  connectSeconds: number
  stats: { latencyMs: number; jitterMs: number; quality: string } | null
  peerName: string | null
  onDone: () => void
}

export function SuccessAnimation({ connectSeconds, stats, peerName, onDone }: SuccessAnimationProps) {
  useEffect(() => {
    const t = setTimeout(() => burstConfetti(), 1050)
    const done = setTimeout(() => onDone(), 3900)
    return () => {
      clearTimeout(t)
      clearTimeout(done)
    }
  }, [])

  return (
    <motion.div
      className="fixed inset-0 z-[90] flex items-center justify-center bg-black/70 backdrop-blur-md"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0, transition: { duration: 0.5 } }}
      role="status"
      aria-live="polite"
    >
      {/* radial glow behind the emblem */}
      <motion.div
        className="absolute h-[28rem] w-[28rem] rounded-full bg-emerald-500/20 blur-[120px]"
        initial={{ opacity: 0, scale: 0.4 }}
        animate={{ opacity: [0, 0.9, 0.55], scale: [0.4, 1.15, 1] }}
        transition={{ duration: 1.4, times: [0, 0.55, 1], ease: 'easeOut' }}
      />

      <div className="relative flex flex-col items-center">
        {/* ---------------- the handshake scene ---------------- */}
        <div className="relative flex h-64 w-[22rem] items-center justify-center sm:w-[26rem]">
          {/* connecting line */}
          <div className="absolute top-1/2 h-px w-64 -translate-y-1/2 overflow-visible bg-white/10">
            {/* signal pulses racing between the two nodes */}
            {[0, 1, 2].map((i) => (
              <motion.span
                key={i}
                className="absolute top-1/2 h-1.5 w-1.5 -translate-y-1/2 rounded-full bg-teal-300 shadow-[0_0_12px_2px_rgba(45,212,191,0.8)]"
                initial={{ left: '0%', opacity: 0 }}
                animate={{ left: ['0%', '100%'], opacity: [0, 1, 1, 0] }}
                transition={{ duration: 0.7, delay: 0.15 + i * 0.22, ease: 'easeInOut' }}
              />
            ))}
          </div>

          {/* left node (you) */}
          <motion.div
            className="absolute left-2 flex h-16 w-16 items-center justify-center rounded-full border border-white/15 bg-white/5 backdrop-blur-sm sm:left-6"
            initial={{ x: 0, scale: 0.6, opacity: 0 }}
            animate={{ x: 'calc(2.9rem + 1.6rem)', scale: [0.6, 1.08, 0.9], opacity: [0, 1, 1] }}
            transition={{ duration: 0.9, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
          >
            <span className="text-xs font-semibold tracking-wide text-white/90">YOU</span>
          </motion.div>

          {/* right node (peer) */}
          <motion.div
            className="absolute right-2 flex h-16 w-16 items-center justify-center rounded-full border border-white/15 bg-white/5 backdrop-blur-sm sm:right-6"
            initial={{ x: 0, scale: 0.6, opacity: 0 }}
            animate={{ x: 'calc(-2.9rem - 1.6rem)', scale: [0.6, 1.08, 0.9], opacity: [0, 1, 1] }}
            transition={{ duration: 0.9, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
          >
            <AudioLines className="h-6 w-6 text-teal-300" aria-hidden />
          </motion.div>

          {/* the pop emblem */}
          <motion.div
            className="absolute top-1/2 left-1/2 z-10 -translate-x-1/2 -translate-y-1/2"
            initial={{ scale: 0, rotate: -30 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ delay: 1.02, type: 'spring', stiffness: 260, damping: 15 }}
          >
            <div className="relative flex h-28 w-28 items-center justify-center rounded-full bg-gradient-to-br from-emerald-400 to-teal-500 shadow-[0_0_60px_10px_rgba(52,211,153,0.45)]">
              {/* inner shine */}
              <div className="absolute inset-1.5 rounded-full bg-gradient-to-tl from-white/25 to-transparent" />
              <motion.svg
                viewBox="0 0 52 52"
                className="h-14 w-14"
                initial="hidden"
                animate="visible"
                aria-hidden
              >
                <motion.path
                  d="M14 27 L23 36 L38 17"
                  fill="none"
                  stroke="#06281f"
                  strokeWidth="5.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  variants={{
                    hidden: { pathLength: 0, opacity: 0 },
                    visible: {
                      pathLength: 1,
                      opacity: 1,
                      transition: { delay: 1.25, duration: 0.45, ease: 'easeOut' },
                    },
                  }}
                />
              </motion.svg>
            </div>
          </motion.div>

          {/* ripple rings */}
          {[0, 1].map((i) => (
            <motion.span
              key={i}
              className="absolute top-1/2 left-1/2 h-28 w-28 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-emerald-400/70"
              initial={{ scale: 0.9, opacity: 0.9 }}
              animate={{ scale: 3.4, opacity: 0 }}
              transition={{ delay: 1.1 + i * 0.28, duration: 1.15, ease: 'easeOut' }}
            />
          ))}
        </div>

        {/* ---------------- headline block ---------------- */}
        <motion.div
          className="mt-2 flex flex-col items-center text-center"
          initial={{ opacity: 0, y: 26 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.45, duration: 0.55, ease: 'easeOut' }}
        >
          <h2 className="bg-gradient-to-r from-emerald-300 via-teal-200 to-emerald-300 bg-clip-text text-3xl font-bold tracking-tight text-transparent sm:text-4xl">
            Connection Established
          </h2>
          <p className="mt-2 text-sm text-white/60 sm:text-base">
            You are now linked with <span className="font-semibold text-white/85">{peerName ?? 'your peer'}</span> — media is flowing peer-to-peer.
          </p>

          <div className="mt-5 flex flex-wrap items-center justify-center gap-2.5 text-xs sm:text-sm">
            <span className="flex items-center gap-1.5 rounded-full border border-emerald-400/25 bg-emerald-400/10 px-3.5 py-1.5 font-medium text-emerald-300">
              <Zap className="h-3.5 w-3.5" aria-hidden />
              Connected in {connectSeconds.toFixed(1)}s
            </span>
            {stats && (
              <>
                <span className="flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-3.5 py-1.5 font-medium text-white/75">
                  <AudioLines className="h-3.5 w-3.5 text-teal-300" aria-hidden />
                  {stats.latencyMs}ms latency · {stats.jitterMs}ms jitter
                </span>
                <span className="flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-3.5 py-1.5 font-medium text-white/75">
                  <ShieldCheck className="h-3.5 w-3.5 text-emerald-300" aria-hidden />
                  {stats.quality === 'excellent' ? 'Excellent link' : 'Stable link'} · encrypted
                </span>
              </>
            )}
          </div>
        </motion.div>
      </div>
    </motion.div>
  )
}
