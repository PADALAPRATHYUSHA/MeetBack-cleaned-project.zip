'use client'

import { useEffect, useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import {
  PieChart, Pie, Cell, ResponsiveContainer, RadialBarChart, RadialBar, PolarAngleAxis,
} from 'recharts'
import {
  Sparkles, Clock, Users, MessageSquare, Gauge, CheckCircle2, Circle,
  Lightbulb, TrendingUp, Copy, RotateCcw, Loader2,
} from 'lucide-react'
import type { MeetingRecord, HindsightInsight } from '@/lib/meetback-types'

interface HindsightViewProps {
  record: MeetingRecord
  insight: HindsightInsight | null
  insightSource: 'ai' | 'local' | null
  onRestart: () => void
}

export function HindsightView({ record, insight, insightSource, onRestart }: HindsightViewProps) {
  const [checked, setChecked] = useState<Record<number, boolean>>({})
  const [copied, setCopied] = useState(false)

  const durationSec = Math.max(1, Math.round((record.endedAt - record.startedAt) / 1000))
  const mins = Math.floor(durationSec / 60)
  const secs = durationSec % 60

  const talkData = useMemo(() => {
    const mine = record.messages.filter((m) => m.kind === 'user').length
    const humanCount = Math.max(1, record.participants.filter((p) => !p.isBot).length)
    const perHuman = Math.max(1, Math.round((mine / humanCount) * 0.55))
    const botShare = Math.max(0, mine - perHuman)
    return [
      { name: record.participants[0]?.name ?? 'You', value: perHuman, color: '#34d399' },
      ...(botShare > 0
        ? [{ name: 'Others', value: botShare, color: '#fbbf24' }]
        : [{ name: 'Listening', value: Math.max(2, perHuman), color: '#525252' }]),
    ]
  }, [record])

  const sentiment = insight?.sentimentScore ?? 80

  const copyRecap = async () => {
    if (!insight) return
    const text = [
      `Hindsight — ${record.code}`,
      insight.headline,
      '',
      insight.summary,
      '',
      'Highlights:',
      ...insight.highlights.map((h) => `• ${h}`),
      '',
      'Action items:',
      ...insight.actionItems.map((a) => `• ${a}`),
    ].join('\n')
    try {
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 1800)
    } catch {
      /* noop */
    }
  }

  return (
    <div className="min-h-screen overflow-y-auto bg-neutral-950 text-white">
      <div className="pointer-events-none fixed inset-0" aria-hidden>
        <div className="absolute -top-24 left-1/2 h-96 w-[46rem] -translate-x-1/2 rounded-full bg-emerald-500/[0.09] blur-[130px]" />
      </div>

      <div className="relative mx-auto w-full max-w-5xl px-5 py-10 sm:px-8">
        {/* header */}
        <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <div className="mb-2 inline-flex items-center gap-2 rounded-full border border-amber-400/25 bg-amber-400/10 px-3 py-1 text-xs font-semibold text-amber-300">
              <Sparkles className="h-3.5 w-3.5" aria-hidden />
              Hindsight · AI meeting recap
              {insightSource === 'ai' && (
                <span className="rounded-full bg-amber-400/20 px-1.5 py-0.5 text-[10px] tracking-wide uppercase">LLM</span>
              )}
            </div>
            <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">
              {insight ? insight.headline : 'Analyzing your meeting…'}
            </h1>
            <p className="mt-1.5 text-sm text-white/45">
              Room <span className="font-mono text-emerald-300">{record.code}</span> · ended just now
            </p>
          </div>
          <div className="flex gap-2.5">
            <Button onClick={copyRecap} disabled={!insight} variant="outline" className="cursor-pointer border-white/15 bg-white/5 text-white hover:bg-white/10 hover:text-white disabled:opacity-40">
              {copied ? <CheckCircle2 className="mr-2 h-4 w-4 text-emerald-400" aria-hidden /> : <Copy className="mr-2 h-4 w-4" aria-hidden />}
              {copied ? 'Copied!' : 'Copy recap'}
            </Button>
            <Button onClick={onRestart} className="cursor-pointer bg-gradient-to-r from-emerald-400 to-teal-500 font-semibold text-neutral-950 hover:from-emerald-300 hover:to-teal-400">
              <RotateCcw className="mr-2 h-4 w-4" aria-hidden />
              New meeting
            </Button>
          </div>
        </motion.div>

        {/* stat row */}
        <div className="mt-8 grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
          {[
            { icon: <Clock className="h-4 w-4 text-emerald-300" aria-hidden />, label: 'Duration', value: mins > 0 ? `${mins}m ${secs}s` : `${secs}s` },
            { icon: <Users className="h-4 w-4 text-teal-300" aria-hidden />, label: 'Participants', value: String(record.participants.length) },
            { icon: <MessageSquare className="h-4 w-4 text-amber-300" aria-hidden />, label: 'Messages', value: String(record.messages.filter((m) => m.kind === 'user').length) },
            { icon: <Gauge className="h-4 w-4 text-emerald-300" aria-hidden />, label: 'Latency', value: record.stats ? `${record.stats.latencyMs}ms` : '—' },
          ].map((s, i) => (
            <motion.div
              key={s.label}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 + i * 0.07 }}
              className="rounded-2xl border border-white/8 bg-white/[0.04] p-4 backdrop-blur"
            >
              <div className="flex items-center gap-2 text-xs text-white/50">{s.icon}{s.label}</div>
              <p className="mt-2 text-2xl font-bold tabular-nums">{s.value}</p>
            </motion.div>
          ))}
        </div>

        {/* charts row */}
        <div className="mt-4 grid gap-4 lg:grid-cols-3">
          <motion.section
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="rounded-2xl border border-white/8 bg-white/[0.04] p-5 backdrop-blur"
          >
            <h3 className="text-sm font-semibold">Conversation split</h3>
            <p className="text-xs text-white/40">Chat activity share</p>
            <div className="mt-2 h-44">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={talkData} dataKey="value" innerRadius={48} outerRadius={70} paddingAngle={4} strokeWidth={0}>
                    {talkData.map((d) => (
                      <Cell key={d.name} fill={d.color} />
                    ))}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex flex-wrap justify-center gap-3">
              {talkData.map((d) => (
                <span key={d.name} className="flex items-center gap-1.5 text-xs text-white/60">
                  <span className="h-2 w-2 rounded-full" style={{ background: d.color }} aria-hidden />
                  {d.name}
                </span>
              ))}
            </div>
          </motion.section>

          <motion.section
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.37 }}
            className="rounded-2xl border border-white/8 bg-white/[0.04] p-5 backdrop-blur"
          >
            <h3 className="text-sm font-semibold">Room sentiment</h3>
            <p className="text-xs text-white/40">{insight?.sentimentLabel ?? 'Measuring…'}</p>
            <div className="mt-1 h-44">
              <ResponsiveContainer width="100%" height="100%">
                <RadialBarChart
                  data={[{ name: 'sentiment', value: sentiment, fill: sentiment > 70 ? '#34d399' : sentiment > 45 ? '#fbbf24' : '#f87171' }]}
                  innerRadius="70%"
                  outerRadius="100%"
                  startAngle={210}
                  endAngle={-30}
                >
                  <PolarAngleAxis type="number" domain={[0, 100]} tick={false} />
                  <RadialBar background={{ fill: '#262626' }} dataKey="value" cornerRadius={12} />
                </RadialBarChart>
              </ResponsiveContainer>
            </div>
            <p className="-mt-14 text-center text-3xl font-bold tabular-nums">
              {sentiment}
              <span className="text-sm font-medium text-white/40">/100</span>
            </p>
            <p className="mt-9 text-center text-xs text-white/40">vibe score across chat + call signals</p>
          </motion.section>

          <motion.section
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.44 }}
            className="rounded-2xl border border-white/8 bg-white/[0.04] p-5 backdrop-blur"
          >
            <h3 className="flex items-center gap-2 text-sm font-semibold">
              <TrendingUp className="h-4 w-4 text-emerald-300" aria-hidden />
              Key moments
            </h3>
            <ul className="mt-3 space-y-2.5">
              {(insight?.highlights ?? []).slice(0, 4).map((h, i) => (
                <motion.li
                  key={i}
                  initial={{ opacity: 0, x: 12 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.5 + i * 0.08 }}
                  className="flex items-start gap-2.5 rounded-xl border border-white/5 bg-white/[0.03] px-3 py-2.5 text-sm text-white/75"
                >
                  <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-md bg-emerald-400/15 text-[10px] font-bold text-emerald-300">
                    {i + 1}
                  </span>
                  {h}
                </motion.li>
              ))}
              {!insight && [0, 1, 2].map((i) => <Skeleton key={i} className="h-11 w-full bg-white/5" />)}
            </ul>
          </motion.section>
        </div>

        {/* AI summary */}
        <motion.section
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="mt-4 rounded-2xl border border-white/8 bg-white/[0.04] p-6 backdrop-blur"
        >
          <h3 className="flex items-center gap-2 text-sm font-semibold">
            <Sparkles className="h-4 w-4 text-amber-300" aria-hidden />
            What Hindsight noticed
          </h3>
          {insight ? (
            <p className="mt-3 max-w-4xl text-[15px] leading-relaxed text-white/75">{insight.summary}</p>
          ) : (
            <div className="mt-4 flex items-center gap-3 text-sm text-white/50">
              <Loader2 className="h-4 w-4 animate-spin text-emerald-300" aria-hidden />
              Crunching the transcript, timing and connection quality…
            </div>
          )}
        </motion.section>

        {/* action items + suggestions */}
        <div className="mt-4 grid gap-4 pb-14 lg:grid-cols-2">
          <motion.section
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.56 }}
            className="rounded-2xl border border-white/8 bg-white/[0.04] p-6 backdrop-blur"
          >
            <h3 className="text-sm font-semibold">Action items</h3>
            <ul className="mt-3.5 space-y-2.5">
              {(insight?.actionItems ?? []).map((a, i) => (
                <li key={i}>
                  <button
                    onClick={() => setChecked((c) => ({ ...c, [i]: !c[i] }))}
                    className="flex w-full cursor-pointer items-start gap-3 rounded-xl border border-white/5 bg-white/[0.03] px-3.5 py-3 text-left text-sm text-white/80 transition-colors hover:bg-white/[0.06]"
                  >
                    {checked[i] ? (
                      <CheckCircle2 className="mt-0.5 h-4.5 w-4.5 shrink-0 text-emerald-400" aria-hidden />
                    ) : (
                      <Circle className="mt-0.5 h-4.5 w-4.5 shrink-0 text-white/30" aria-hidden />
                    )}
                    <span className={checked[i] ? 'text-white/35 line-through' : ''}>{a}</span>
                  </button>
                </li>
              ))}
            </ul>
          </motion.section>

          <motion.section
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.62 }}
            className="rounded-2xl border border-white/8 bg-white/[0.04] p-6 backdrop-blur"
          >
            <h3 className="flex items-center gap-2 text-sm font-semibold">
              <Lightbulb className="h-4 w-4 text-amber-300" aria-hidden />
              For your next meeting
            </h3>
            <ul className="mt-3.5 space-y-2.5">
              {(insight?.suggestions ?? []).map((s, i) => (
                <li key={i} className="flex items-start gap-3 rounded-xl border border-white/5 bg-white/[0.03] px-3.5 py-3 text-sm text-white/80">
                  <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-amber-300" aria-hidden />
                  {s}
                </li>
              ))}
            </ul>
          </motion.section>
        </div>
      </div>
    </div>
  )
}
