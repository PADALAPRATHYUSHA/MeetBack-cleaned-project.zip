'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Sparkles, Video, ArrowRight, Radio, BarChart3, ShieldCheck, LogIn } from 'lucide-react'

interface LandingViewProps {
  onHost: (name: string, demo: boolean) => void
  onJoin: (name: string, code: string) => void
  defaultName: string
}

const FEATURES = [
  {
    icon: <Radio className="h-4 w-4 text-emerald-400" aria-hidden />,
    title: 'Instant P2P rooms',
    desc: 'Share a 6-char code, connect in under 3 seconds.',
  },
  {
    icon: <Sparkles className="h-4 w-4 text-amber-400" aria-hidden />,
    title: 'Connection you can feel',
    desc: 'A celebratory handshake animation the moment your link goes live.',
  },
  {
    icon: <BarChart3 className="h-4 w-4 text-teal-300" aria-hidden />,
    title: 'Hindsight recap',
    desc: 'AI-crafted post-meeting insights: sentiment, talk-time, action items.',
  },
]

export function LandingView({ onHost, onJoin, defaultName }: LandingViewProps) {
  const [name, setName] = useState(defaultName)
  const [joinCode, setJoinCode] = useState('')
  const [mode, setMode] = useState<'idle' | 'joining'>('idle')

  const startHosting = () => {
    if (!name.trim()) return
    onHost(name.trim(), true)
  }

  const startJoining = () => {
    if (!name.trim() || joinCode.trim().length < 4) return
    onJoin(name.trim(), joinCode.trim().toUpperCase())
  }

  return (
    <div className="relative flex min-h-screen flex-col overflow-hidden bg-neutral-950 text-white">
      {/* ambient background */}
      <div className="pointer-events-none absolute inset-0" aria-hidden>
        <div className="absolute -top-32 left-1/2 h-[34rem] w-[54rem] -translate-x-1/2 rounded-full bg-emerald-500/[0.13] blur-[130px]" />
        <div className="absolute bottom-0 right-0 h-72 w-72 rounded-full bg-teal-500/10 blur-[110px]" />
        <div
          className="absolute inset-0 opacity-[0.035]"
          style={{
            backgroundImage:
              'linear-gradient(rgba(255,255,255,.6) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.6) 1px, transparent 1px)',
            backgroundSize: '56px 56px',
          }}
        />
      </div>

      <header className="relative z-10 mx-auto flex w-full max-w-6xl items-center justify-between px-6 py-6">
        <div className="flex items-center gap-2.5">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-400 to-teal-500 shadow-[0_0_24px_rgba(52,211,153,0.4)]">
            <Video className="h-4.5 w-4.5 text-neutral-950" aria-hidden />
          </div>
          <span className="text-lg font-bold tracking-tight">
            Meet<span className="text-emerald-400">Back</span>
          </span>
        </div>
        <Badge variant="outline" className="border-white/15 bg-white/5 text-white/70">
          <Sparkles className="mr-1 h-3 w-3 text-amber-400" aria-hidden />
          Build v1.0
        </Badge>
      </header>

      <main className="relative z-10 mx-auto grid w-full max-w-6xl flex-1 items-center gap-12 px-6 pb-16 lg:grid-cols-2 lg:gap-8">
        {/* hero copy */}
        <motion.section
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: 'easeOut' }}
          className="max-w-xl"
        >
          <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-emerald-400/20 bg-emerald-400/[0.08] px-3.5 py-1.5 text-xs font-medium text-emerald-300">
            <span className="relative flex h-2 w-2" aria-hidden>
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
            </span>
            Live peer-to-peer · no downloads
          </div>
          <h1 className="text-4xl leading-[1.08] font-bold tracking-tight sm:text-5xl lg:text-6xl">
            Meetings that end with a
            <span className="bg-gradient-to-r from-emerald-300 via-teal-200 to-emerald-300 bg-clip-text text-transparent"> round of applause.</span>
          </h1>
          <p className="mt-5 text-base leading-relaxed text-white/55 sm:text-lg">
            MeetBack pairs buttery-smooth video rooms with an instant <span className="text-white/85">connection celebration</span> — and closes every call with <span className="text-white/85">Hindsight</span>, an AI recap of what actually happened.
          </p>

          <ul className="mt-8 space-y-4">
            {FEATURES.map((f, i) => (
              <motion.li
                key={f.title}
                initial={{ opacity: 0, x: -16 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.15 + i * 0.1 }}
                className="flex items-start gap-3"
              >
                <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-white/10 bg-white/5">
                  {f.icon}
                </span>
                <span>
                  <span className="block text-sm font-semibold text-white/90">{f.title}</span>
                  <span className="block text-sm text-white/50">{f.desc}</span>
                </span>
              </motion.li>
            ))}
          </ul>
        </motion.section>

        {/* action card */}
        <motion.section
          initial={{ opacity: 0, y: 24, scale: 0.97 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.1, ease: 'easeOut' }}
          className="w-full max-w-md justify-self-center lg:justify-self-end"
        >
          <div className="rounded-3xl border border-white/10 bg-white/[0.04] p-6 shadow-2xl backdrop-blur-xl sm:p-8">
            <h2 className="text-lg font-semibold">Start a meeting</h2>
            <p className="mt-1 text-sm text-white/50">Your name is all we need.</p>

            <div className="mt-6 space-y-2.5">
              <label htmlFor="display-name" className="text-xs font-medium tracking-wide text-white/60 uppercase">
                Display name
              </label>
              <Input
                id="display-name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Jordan Rivera"
                maxLength={24}
                className="h-11 border-white/10 bg-white/5 text-white placeholder:text-white/30 focus-visible:ring-emerald-400/60"
              />
            </div>

            <Button
              onClick={startHosting}
              disabled={!name.trim()}
              className="mt-4 h-12 w-full cursor-pointer bg-gradient-to-r from-emerald-400 to-teal-500 text-base font-semibold text-neutral-950 shadow-[0_8px_30px_rgba(52,211,153,0.35)] transition-transform hover:scale-[1.015] hover:shadow-[0_8px_36px_rgba(52,211,153,0.5)] disabled:opacity-40"
            >
              <Video className="mr-2 h-5 w-5" aria-hidden />
              Start new meeting
            </Button>

            <div className="my-6 flex items-center gap-3 text-xs text-white/30">
              <span className="h-px flex-1 bg-white/10" />
              or join someone
              <span className="h-px flex-1 bg-white/10" />
            </div>

            <div className="flex gap-2.5">
              <Input
                value={joinCode}
                onChange={(e) => setJoinCode(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6))}
                placeholder="ROOM CODE"
                aria-label="Room code"
                className="h-12 flex-1 border-white/10 bg-white/5 text-center font-mono text-lg tracking-[0.3em] text-emerald-300 placeholder:text-white/25 focus-visible:ring-emerald-400/60"
              />
              <Button
                onClick={() => (mode === 'joining' ? startJoining() : setMode('joining'))}
                disabled={!name.trim()}
                variant="outline"
                aria-label={mode === 'joining' ? 'Join meeting now' : 'Enter a room code'}
                className="h-12 cursor-pointer border-emerald-400/30 bg-emerald-400/10 px-4 font-semibold text-emerald-300 hover:bg-emerald-400/20 hover:text-emerald-200 disabled:opacity-40"
              >
                {mode === 'joining' ? <LogIn className="h-5 w-5" aria-hidden /> : <ArrowRight className="h-5 w-5" aria-hidden />}
              </Button>
            </div>
            {mode === 'joining' && (
              <p className="mt-2.5 text-xs text-white/40">
                Type the 6-character code, then press the arrow to join — you&apos;ll appear in the room instantly.
              </p>
            )}

            <p className="mt-6 flex items-center justify-center gap-1.5 text-xs text-white/35">
              <ShieldCheck className="h-3.5 w-3.5 text-emerald-400/70" aria-hidden />
              Peer-to-peer media · DTLS encrypted · nothing recorded
            </p>
          </div>
        </motion.section>
      </main>

      <footer className="relative z-10 mt-auto border-t border-white/5 py-5 text-center text-xs text-white/30">
        MeetBack — built for learning and demos · solo demo spawns a simulated peer so the magic always shows
      </footer>
    </div>
  )
}
