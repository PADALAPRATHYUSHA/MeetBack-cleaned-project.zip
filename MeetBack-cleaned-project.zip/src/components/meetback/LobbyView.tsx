'use client'

import { useEffect, useRef } from 'react'
import { motion } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { Mic, MicOff, Video as VideoIcon, VideoOff, ArrowRight, CameraOff } from 'lucide-react'

interface LobbyViewProps {
  userName: string
  roomCode: string
  stream: MediaStream | null
  muted: boolean
  camOff: boolean
  onToggleMute: () => void
  onToggleCam: () => void
  onEnter: () => void
  onBack: () => void
}

export function LobbyView({
  userName,
  roomCode,
  stream,
  muted,
  camOff,
  onToggleMute,
  onToggleCam,
  onEnter,
  onBack,
}: LobbyViewProps) {
  const videoRef = useRef<HTMLVideoElement>(null)

  useEffect(() => {
    if (videoRef.current && stream) {
      videoRef.current.srcObject = stream
      videoRef.current.play().catch(() => undefined)
    }
  }, [stream])

  const mediaError = stream === null ? 'Camera unavailable — you can still join with an avatar.' : null

  return (
    <div className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden bg-neutral-950 px-4 py-10 text-white">
      <div className="pointer-events-none absolute inset-0" aria-hidden>
        <div className="absolute top-1/4 left-1/2 h-96 w-96 -translate-x-1/2 rounded-full bg-emerald-500/10 blur-[120px]" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="relative w-full max-w-lg"
      >
        <button
          onClick={onBack}
          className="mb-5 cursor-pointer text-sm text-white/45 transition-colors hover:text-white/80"
        >
          ← back to home
        </button>

        <div className="overflow-hidden rounded-3xl border border-white/10 bg-white/[0.04] shadow-2xl backdrop-blur-xl">
          {/* camera preview */}
          <div className="relative aspect-video bg-black">
            {stream && !camOff ? (
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="h-full w-full scale-x-[-1] object-cover"
              />
            ) : (
              <div className="flex h-full w-full flex-col items-center justify-center gap-3 bg-gradient-to-br from-neutral-900 to-neutral-950">
                <div
                  className="flex h-20 w-20 items-center justify-center rounded-full text-3xl font-bold text-neutral-950"
                  style={{ background: 'linear-gradient(135deg,#34d399,#2dd4bf)' }}
                  aria-hidden
                >
                  {userName.charAt(0).toUpperCase()}
                </div>
                <p className="flex items-center gap-1.5 text-xs text-white/40">
                  <CameraOff className="h-3.5 w-3.5" aria-hidden />
                  {camOff ? 'Camera is off' : 'No camera detected'}
                </p>
              </div>
            )}

            {/* status chips */}
            <div className="absolute top-3 left-3 flex items-center gap-2">
              <span className="flex items-center gap-1.5 rounded-full bg-black/50 px-3 py-1 text-xs font-medium text-white/85 backdrop-blur">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" aria-hidden />
                Ready — room {roomCode}
              </span>
            </div>
            <div className="absolute right-3 bottom-3 flex gap-2">
              <button
                onClick={onToggleMute}
                aria-label={muted ? 'Unmute microphone' : 'Mute microphone'}
                className={`flex h-10 w-10 cursor-pointer items-center justify-center rounded-full backdrop-blur transition-colors ${
                  muted ? 'bg-red-500/90 text-white' : 'bg-white/15 text-white hover:bg-white/25'
                }`}
              >
                {muted ? <MicOff className="h-4.5 w-4.5" aria-hidden /> : <Mic className="h-4.5 w-4.5" aria-hidden />}
              </button>
              <button
                onClick={onToggleCam}
                aria-label={camOff ? 'Turn camera on' : 'Turn camera off'}
                className={`flex h-10 w-10 cursor-pointer items-center justify-center rounded-full backdrop-blur transition-colors ${
                  camOff ? 'bg-red-500/90 text-white' : 'bg-white/15 text-white hover:bg-white/25'
                }`}
              >
                {camOff ? <VideoOff className="h-4.5 w-4.5" aria-hidden /> : <VideoIcon className="h-4.5 w-4.5" aria-hidden />}
              </button>
            </div>
          </div>

          <div className="p-6">
            <h2 className="text-lg font-semibold">You look great, {userName.split(' ')[0]}</h2>
            <p className="mt-1 text-sm text-white/50">
              {mediaError
                ? mediaError
                : 'Check your framing and audio, then step into the room. Your peer will be notified the moment you enter.'}
            </p>
            <Button
              onClick={onEnter}
              className="mt-5 h-12 w-full cursor-pointer bg-gradient-to-r from-emerald-400 to-teal-500 text-base font-semibold text-neutral-950 shadow-[0_8px_30px_rgba(52,211,153,0.35)] transition-transform hover:scale-[1.01]"
            >
              Enter meeting now
              <ArrowRight className="ml-2 h-5 w-5" aria-hidden />
            </Button>
          </div>
        </div>
      </motion.div>
    </div>
  )
}
