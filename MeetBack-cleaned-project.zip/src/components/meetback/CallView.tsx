'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { ScrollArea } from '@/components/ui/scroll-area'
import {
  Mic, MicOff, Video as VideoIcon, VideoOff, MonitorUp, Smile, MessageSquare, PhoneOff,
  Copy, Check, Signal, X, Send, Users,
} from 'lucide-react'
import type { ChatMessage, ConnectionStats, Participant } from '@/lib/meetback-types'

export interface FloatingReaction {
  key: string
  emoji: string
  name: string
  x: number
}

interface CallViewProps {
  meId: string
  roomCode: string
  participants: Participant[]
  messages: ChatMessage[]
  stream: MediaStream | null
  muted: boolean
  camOff: boolean
  stats: ConnectionStats | null
  speaking: Record<string, boolean>
  reactions: FloatingReaction[]
  elapsed: number
  onToggleMute: () => void
  onToggleCam: () => void
  onSendChat: (content: string) => void
  onReact: (emoji: string) => void
  onEnd: () => void
}

const EMOJIS = ['👏', '🔥', '❤️', '😂', '👍', '🎉', '😮', '💯']

function fmtTime(sec: number) {
  const m = Math.floor(sec / 60)
  const s = sec % 60
  return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`
}

export function CallView({
  meId, roomCode, participants, messages, stream, muted, camOff,
  stats, speaking, reactions, elapsed,
  onToggleMute, onToggleCam, onSendChat, onReact, onEnd,
}: CallViewProps) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const chatEndRef = useRef<HTMLDivElement>(null)
  const [copied, setCopied] = useState(false)
  const [chatOpen, setChatOpen] = useState(false)
  const [showEmojis, setShowEmojis] = useState(false)
  const [draft, setDraft] = useState('')
  const [lastSeen, setLastSeen] = useState(0)

  useEffect(() => {
    if (videoRef.current && stream) {
      videoRef.current.srcObject = stream
      videoRef.current.play().catch(() => undefined)
    }
  }, [stream])

  useEffect(() => {
    if (chatOpen) {
      chatEndRef.current?.scrollIntoView({ behavior: 'smooth' })
    }
  }, [chatOpen, messages.length])

  const openChat = () => {
    setLastSeen(messages.length)
    setChatOpen(true)
  }
  const closeChat = () => {
    setLastSeen(messages.length)
    setChatOpen(false)
  }

  const unread = Math.max(0, messages.length - lastSeen)

  const copyCode = async () => {
    try {
      await navigator.clipboard.writeText(roomCode)
      setCopied(true)
      setTimeout(() => setCopied(false), 1600)
    } catch {
      /* clipboard unavailable */
    }
  }

  const gridCols = useMemo(() => {
    const n = Math.max(1, participants.length)
    if (n <= 1) return 'grid-cols-1'
    if (n <= 4) return 'grid-cols-1 sm:grid-cols-2'
    return 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3'
  }, [participants.length])

  return (
    <div className="flex h-screen flex-col overflow-hidden bg-neutral-950 text-white">
      {/* ------------------------------- header ------------------------------- */}
      <header className="flex items-center justify-between gap-3 border-b border-white/5 px-4 py-3 sm:px-6">
        <div className="flex min-w-0 items-center gap-3">
          <button
            onClick={copyCode}
            className="group flex cursor-pointer items-center gap-2 rounded-full border border-white/10 bg-white/5 py-1.5 pr-3 pl-3 transition-colors hover:bg-white/10"
            aria-label={`Copy room code ${roomCode}`}
          >
            <span className="font-mono text-sm font-bold tracking-[0.18em] text-emerald-300">{roomCode}</span>
            {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" aria-hidden /> : <Copy className="h-3.5 w-3.5 text-white/40 group-hover:text-white/70" aria-hidden />}
          </button>
          <span className="hidden font-mono text-sm text-white/50 tabular-nums sm:block">{fmtTime(elapsed)}</span>
        </div>

        <div className="flex items-center gap-2.5">
          {stats && (
            <span
              className={`flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-medium ${
                stats.quality === 'excellent'
                  ? 'border-emerald-400/25 bg-emerald-400/10 text-emerald-300'
                  : 'border-amber-400/25 bg-amber-400/10 text-amber-300'
              }`}
              title={`${stats.latencyMs}ms latency, ${stats.jitterMs}ms jitter`}
            >
              <Signal className="h-3.5 w-3.5" aria-hidden />
              {stats.latencyMs}ms · {stats.quality}
            </span>
          )}
          <span className="flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs text-white/70">
            <Users className="h-3.5 w-3.5" aria-hidden />
            {participants.length}
          </span>
        </div>
      </header>

      <div className="flex min-h-0 flex-1">
        {/* ------------------------------ video grid ---------------------------- */}
        <main className="relative min-w-0 flex-1 p-3 sm:p-5">
          <div className={`grid h-full min-h-0 gap-3 sm:gap-4 ${gridCols}`}>
            <AnimatePresence>
              {participants.map((p) => {
                const isMe = p.id === meId
                const isSpeaking = !!speaking[p.id]
                return (
                  <motion.div
                    key={p.id}
                    layout
                    initial={{ opacity: 0, scale: 0.92 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.92 }}
                    transition={{ duration: 0.35 }}
                    className={`relative min-h-[220px] overflow-hidden rounded-2xl border bg-neutral-900 ${
                      isSpeaking ? 'border-emerald-400/60 shadow-[0_0_28px_rgba(52,211,153,0.25)]' : 'border-white/8'
                    }`}
                  >
                    {isMe && stream && !camOff ? (
                      <video ref={videoRef} autoPlay playsInline muted className="h-full w-full scale-x-[-1] object-cover" />
                    ) : (
                      <div className="flex h-full w-full flex-col items-center justify-center gap-3 bg-gradient-to-br from-neutral-900 via-neutral-950 to-black">
                        <div className="relative">
                          {isSpeaking && (
                            <motion.span
                              className="absolute inset-0 rounded-full border-2 border-emerald-400/70"
                              animate={{ scale: [1, 1.35], opacity: [0.9, 0] }}
                              transition={{ duration: 1.1, repeat: Infinity, ease: 'easeOut' }}
                              aria-hidden
                            />
                          )}
                          <div
                            className="flex h-20 w-20 items-center justify-center rounded-full text-3xl font-bold text-neutral-950 sm:h-24 sm:w-24"
                            style={{ background: `linear-gradient(135deg, ${p.color}, ${p.color}88)` }}
                            aria-hidden
                          >
                            {p.name.charAt(0).toUpperCase()}
                          </div>
                        </div>
                        {!p.isBot && !isMe && (
                          <span className="text-xs text-white/40">live · peer-to-peer</span>
                        )}
                      </div>
                    )}

                    {/* name tag */}
                    <div className="absolute bottom-3 left-3 flex items-center gap-2 rounded-full bg-black/55 px-3 py-1.5 text-xs font-medium backdrop-blur">
                      {p.muted ? <MicOff className="h-3.5 w-3.5 text-red-400" aria-hidden /> : <Mic className="h-3.5 w-3.5 text-emerald-300" aria-hidden />}
                      {p.camOff && isMe ? <VideoOff className="h-3.5 w-3.5 text-red-400" aria-hidden /> : null}
                      <span className="max-w-[10rem] truncate">{p.name}{isMe ? ' (you)' : ''}</span>
                    </div>
                  </motion.div>
                )
              })}
            </AnimatePresence>
          </div>

          {/* floating reactions */}
          <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden>
            <AnimatePresence>
              {reactions.map((r) => (
                <motion.span
                  key={r.key}
                  className="absolute text-3xl"
                  style={{ left: `${r.x}%`, bottom: '6rem' }}
                  initial={{ y: 0, opacity: 0, scale: 0.5 }}
                  animate={{ y: -260, opacity: [0, 1, 1, 0], scale: [0.5, 1.3, 1, 0.9] }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 2.4, ease: 'easeOut' }}
                >
                  {r.emoji}
                </motion.span>
              ))}
            </AnimatePresence>
          </div>
        </main>

        {/* -------------------------------- chat -------------------------------- */}
        <AnimatePresence>
          {chatOpen && (
            <motion.aside
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: '22rem', opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
              transition={{ duration: 0.28, ease: 'easeOut' }}
              className="hidden flex-col overflow-hidden border-l border-white/5 bg-neutral-950/90 md:flex"
              aria-label="Meeting chat"
            >
              <div className="flex items-center justify-between border-b border-white/5 px-4 py-3.5">
                <h3 className="text-sm font-semibold">In-call messages</h3>
                <button onClick={closeChat} className="cursor-pointer text-white/40 hover:text-white" aria-label="Close chat">
                  <X className="h-4.5 w-4.5" aria-hidden />
                </button>
              </div>
              <ScrollArea className="min-h-0 flex-1 px-4">
                <div className="space-y-3 py-4">
                  {messages.map((m) =>
                    m.kind === 'system' ? (
                      <p key={m.id} className="text-center text-[11px] text-emerald-300/60 italic">{m.content}</p>
                    ) : (
                      <div key={m.id} className="rounded-xl border border-white/5 bg-white/[0.03] px-3 py-2.5">
                        <p className="text-xs font-semibold text-emerald-300/90">{m.name}</p>
                        <p className="mt-0.5 text-sm break-words text-white/80">{m.content}</p>
                      </div>
                    )
                  )}
                  <div ref={chatEndRef} />
                </div>
              </ScrollArea>
              <form
                className="flex gap-2 border-t border-white/5 p-3.5"
                onSubmit={(e) => {
                  e.preventDefault()
                  if (!draft.trim()) return
                  onSendChat(draft.trim())
                  setDraft('')
                }}
              >
                <Input
                  value={draft}
                  onChange={(e) => setDraft(e.target.value)}
                  placeholder="Message everyone…"
                  className="h-10 border-white/10 bg-white/5 text-sm text-white placeholder:text-white/30 focus-visible:ring-emerald-400/60"
                />
                <Button type="submit" size="icon" disabled={!draft.trim()} className="h-10 w-10 shrink-0 cursor-pointer bg-emerald-400 text-neutral-950 hover:bg-emerald-300 disabled:opacity-30" aria-label="Send message">
                  <Send className="h-4 w-4" aria-hidden />
                </Button>
              </form>
            </motion.aside>
          )}
        </AnimatePresence>
      </div>

      {/* ------------------------------ controls ------------------------------ */}
      <footer className="flex items-center justify-center gap-2 border-t border-white/5 px-4 py-4 sm:gap-3">
        <ControlButton active={!muted} danger={muted} onClick={onToggleMute} label={muted ? 'Unmute' : 'Mute'}>
          {muted ? <MicOff className="h-5 w-5" aria-hidden /> : <Mic className="h-5 w-5" aria-hidden />}
        </ControlButton>
        <ControlButton active={!camOff} danger={camOff} onClick={onToggleCam} label={camOff ? 'Start video' : 'Stop video'}>
          {camOff ? <VideoOff className="h-5 w-5" aria-hidden /> : <VideoIcon className="h-5 w-5" aria-hidden />}
        </ControlButton>
        <ControlButton active={false} onClick={() => undefined} label="Share screen">
          <MonitorUp className="h-5 w-5" aria-hidden />
        </ControlButton>

        {/* emoji picker */}
        <div className="relative">
          <ControlButton active={showEmojis} onClick={() => setShowEmojis((v) => !v)} label="React">
            <Smile className="h-5 w-5" aria-hidden />
          </ControlButton>
          <AnimatePresence>
            {showEmojis && (
              <motion.div
                initial={{ opacity: 0, y: 10, scale: 0.9 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 10, scale: 0.9 }}
                className="absolute bottom-16 left-1/2 z-30 flex -translate-x-1/2 gap-1 rounded-2xl border border-white/10 bg-neutral-900/95 p-2 shadow-2xl backdrop-blur"
              >
                {EMOJIS.map((e) => (
                  <button
                    key={e}
                    onClick={() => { onReact(e); setShowEmojis(false) }}
                    className="flex h-10 w-10 cursor-pointer items-center justify-center rounded-xl text-xl transition-transform hover:scale-125 hover:bg-white/5"
                    aria-label={`React with ${e}`}
                  >
                    {e}
                  </button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <ControlButton
          active={chatOpen}
          onClick={() => (chatOpen ? closeChat() : openChat())}
          label="Chat"
          badge={unread > 0 ? unread : undefined}
        >
          <MessageSquare className="h-5 w-5" aria-hidden />
        </ControlButton>

        <Button
          onClick={onEnd}
          className="ml-1 h-12 cursor-pointer rounded-full bg-red-500 px-5 font-semibold text-white shadow-[0_8px_24px_rgba(239,68,68,0.35)] hover:bg-red-400 sm:px-6"
        >
          <PhoneOff className="mr-2 h-4.5 w-4.5" aria-hidden />
          End
        </Button>
      </footer>

      {/* mobile chat drawer */}
      <AnimatePresence>
        {chatOpen && (
          <motion.div
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', damping: 28, stiffness: 260 }}
            className="fixed inset-x-0 bottom-0 z-40 flex h-[62vh] flex-col rounded-t-3xl border-t border-white/10 bg-neutral-950 md:hidden"
          >
            <div className="flex items-center justify-between px-4 py-3.5">
              <h3 className="text-sm font-semibold">In-call messages</h3>
              <button onClick={closeChat} className="cursor-pointer text-white/40" aria-label="Close chat">
                <X className="h-5 w-5" aria-hidden />
              </button>
            </div>
            <ScrollArea className="min-h-0 flex-1 px-4">
              <div className="space-y-3 pb-4">
                {messages.map((m) =>
                  m.kind === 'system' ? (
                    <p key={m.id} className="text-center text-[11px] text-emerald-300/60 italic">{m.content}</p>
                  ) : (
                    <div key={m.id} className="rounded-xl border border-white/5 bg-white/[0.03] px-3 py-2.5">
                      <p className="text-xs font-semibold text-emerald-300/90">{m.name}</p>
                      <p className="mt-0.5 text-sm break-words text-white/80">{m.content}</p>
                    </div>
                  )
                )}
                <div ref={chatEndRef} />
              </div>
            </ScrollArea>
            <form
              className="flex gap-2 border-t border-white/5 p-3.5 pb-6"
              onSubmit={(e) => {
                e.preventDefault()
                if (!draft.trim()) return
                onSendChat(draft.trim())
                setDraft('')
              }}
            >
              <Input value={draft} onChange={(e) => setDraft(e.target.value)} placeholder="Message everyone…" className="h-10 border-white/10 bg-white/5 text-white placeholder:text-white/30" />
              <Button type="submit" size="icon" className="h-10 w-10 shrink-0 bg-emerald-400 text-neutral-950 hover:bg-emerald-300" aria-label="Send message">
                <Send className="h-4 w-4" aria-hidden />
              </Button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

function ControlButton({
  children, active, danger, onClick, label, badge,
}: {
  children: React.ReactNode
  active: boolean
  danger?: boolean
  onClick: () => void
  label: string
  badge?: number
}) {
  return (
    <div className="relative">
      <button
        onClick={onClick}
        aria-label={label}
        title={label}
        className={`flex h-12 w-12 cursor-pointer items-center justify-center rounded-full border transition-all ${
          danger
            ? 'border-red-400/30 bg-red-500/90 text-white hover:bg-red-500'
            : active
              ? 'border-emerald-400/30 bg-emerald-400/15 text-emerald-300 hover:bg-emerald-400/25'
              : 'border-white/10 bg-white/5 text-white/80 hover:bg-white/10'
        }`}
      >
        {children}
      </button>
      {badge !== undefined && badge > 0 && (
        <span className="absolute -top-1 -right-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-emerald-400 px-1 text-[10px] font-bold text-neutral-950">
          {badge}
        </span>
      )}
    </div>
  )
}
