import { MeetBackApp } from '@/components/meetback/MeetBackApp'

export default function Home() {
  return <MeetBackApp />
}
