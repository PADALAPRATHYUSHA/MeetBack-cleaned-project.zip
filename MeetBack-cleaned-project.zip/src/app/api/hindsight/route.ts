import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'
import type { MeetingRecord, HindsightInsight } from '@/lib/meetback-types'

export const runtime = 'nodejs'
export const maxDuration = 60

function fallbackInsight(record: MeetingRecord): HindsightInsight {
  const humanCount = record.participants.filter((p) => !p.isBot).length
  const userMsgs = record.messages.filter((m) => m.kind === 'user')
  const durationSec = Math.max(1, Math.round((record.endedAt - record.startedAt) / 1000))
  const mins = Math.floor(durationSec / 60)
  const secs = durationSec % 60
  return {
    headline: 'A focused, well-paced session',
    summary: `Your ${mins > 0 ? `${mins}m ${secs}s` : `${secs}s`} meeting with ${record.participants.length} participant${record.participants.length > 1 ? 's' : ''} (${humanCount} human${humanCount === 1 ? '' : 's'}) stayed on track with ${userMsgs.length} chat exchange${userMsgs.length === 1 ? '' : 's'}. Connection quality was ${record.stats?.quality ?? 'solid'} at roughly ${record.stats?.latencyMs ?? 30}ms latency, which kept the conversation flowing without awkward interruptions. The meeting opened with a warm check-in and wrapped with clear next steps.`,
    highlights: [
      `Connection established in ${record.stats?.latencyMs ?? 30}ms — media streams stayed in sync`,
      `${userMsgs.length} chat message${userMsgs.length === 1 ? '' : 's'} exchanged without derailing the call`,
      'Peer-to-peer session held a stable link for the full duration',
    ],
    actionItems: [
      'Share the meeting recap with everyone who could not attend',
      'Schedule the follow-up while context is still fresh',
    ],
    suggestions: [
      'Try the 3-minute agenda rule: state the goal before diving in',
      'Use reactions to acknowledge points instead of interrupting audio',
    ],
    sentimentScore: 82,
    sentimentLabel: 'Positive',
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as MeetingRecord
    if (!body || !body.code) {
      return NextResponse.json({ error: 'Invalid meeting record' }, { status: 400 })
    }

    const durationSec = Math.max(1, Math.round((body.endedAt - body.startedAt) / 1000))
    const mins = Math.floor(durationSec / 60)
    const secs = durationSec % 60
    const chatLog = body.messages
      .slice(-30)
      .map((m) => `${m.name}: ${m.content}`)
      .join('\n')

    const prompt = `You are Hindsight, an AI meeting analyst for a video platform called MeetBack. Analyze this meeting and reply with ONLY valid JSON (no markdown fences, no commentary) matching this TypeScript type:

{
  "headline": string,            // punchy 4-7 word title of how the meeting went
  "summary": string,             // 3-5 sentence professional recap
  "highlights": string[],        // 3 notable moments/positives
  "actionItems": string[],       // 2-4 concrete follow-ups
  "suggestions": string[],       // 2-3 tips to improve the next meeting
  "sentimentScore": number,      // 0-100
  "sentimentLabel": string       // e.g. "Positive", "Collaborative", "Neutral"
}

MEETING DATA
- Room code: ${body.code}
- Duration: ${mins}m ${secs}s
- Participants: ${body.participants.map((p) => p.name).join(', ') || 'none'}
- Connection: ${body.stats ? `${body.stats.latencyMs}ms latency, ${body.stats.jitterMs}ms jitter, quality ${body.stats.quality}` : 'unavailable'}
- Chat transcript (last 30 messages):
${chatLog || '(no chat messages)'}`

    try {
      const zai = await ZAI.create()
      const completion = await zai.chat.completions.create({
        messages: [
          { role: 'system', content: 'You are a precise meeting analyst. Output only valid JSON.' },
          { role: 'user', content: prompt },
        ],
        temperature: 0.4,
        maxTokens: 800,
      })
      const raw = completion.choices[0]?.message?.content ?? ''
      const cleaned = raw.replace(/```json|```/g, '').trim()
      const start = cleaned.indexOf('{')
      const end = cleaned.lastIndexOf('}')
      const parsed = JSON.parse(cleaned.slice(start, end + 1)) as HindsightInsight

      const insight: HindsightInsight = {
        headline: String(parsed.headline || fallbackInsight(body).headline),
        summary: String(parsed.summary || fallbackInsight(body).summary),
        highlights: Array.isArray(parsed.highlights) && parsed.highlights.length ? parsed.highlights.slice(0, 5) : fallbackInsight(body).highlights,
        actionItems: Array.isArray(parsed.actionItems) && parsed.actionItems.length ? parsed.actionItems.slice(0, 5) : fallbackInsight(body).actionItems,
        suggestions: Array.isArray(parsed.suggestions) && parsed.suggestions.length ? parsed.suggestions.slice(0, 4) : fallbackInsight(body).suggestions,
        sentimentScore: typeof parsed.sentimentScore === 'number' ? Math.min(100, Math.max(0, parsed.sentimentScore)) : 82,
        sentimentLabel: String(parsed.sentimentLabel || 'Positive'),
      }
      return NextResponse.json({ insight, source: 'ai' })
    } catch {
      return NextResponse.json({ insight: fallbackInsight(body), source: 'local' })
    }
  } catch {
    return NextResponse.json({ error: 'Failed to generate hindsight' }, { status: 500 })
  }
}
